/*
  NovaHogar — frontend starter.
  Public configuration is safe to place here: Supabase project URL + anon/publishable key only.
  NEVER put a service_role/secret key in this file.
*/
const SUPABASE_URL = ""; // e.g. https://xxxxxxxx.supabase.co
const SUPABASE_ANON_KEY = ""; // Supabase anon/publishable key
const isConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase);

const sampleListings = [
  {id:"sample-1",title:"Casa con potencial comercial en zona sur",property_type:"Casa",price_usd:120000,location:"Av. Transcontinental / Plan 3000, Santa Cruz",land_m2:292.56,built_m2:280.20,description:"Propiedad de dos plantas con 4 dormitorios, 4 baños, garaje y dos tiendas hacia la calle. Incluye obra bruta con potencial para departamentos.",phone:"",sample:true}
];
let allListings = [];

const grid = document.getElementById("listingGrid");
const count = document.getElementById("listingCount");
document.getElementById("year").textContent = new Date().getFullYear();

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function money(value) {
  return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0}).format(Number(value)||0);
}
function card(item) {
  const type = escapeHTML(item.property_type || "Propiedad");
  const specs = [];
  if (item.land_m2) specs.push(`⌂ ${escapeHTML(item.land_m2)} m² terreno`);
  if (item.built_m2) specs.push(`▦ ${escapeHTML(item.built_m2)} m² construidos`);
  const contact = item.phone ? `https://wa.me/${String(item.phone).replace(/\D/g,"")}?text=${encodeURIComponent("Hola, vi tu propiedad en NovaHogar: "+item.title)}` : "";
  return `<article class="property-card">
    <div class="property-art"><span class="tag">${type}</span><span aria-hidden="true">⌂</span></div>
    <div class="property-info"><p class="property-price">${money(item.price_usd)}</p><h3>${escapeHTML(item.title)}</h3>
    <p class="property-location">⌖ ${escapeHTML(item.location)}</p>
    <div class="property-specs">${specs.join("") || "Consulta los detalles"}</div>
    <p class="fine-print">${escapeHTML(item.description || "").slice(0,170)}${String(item.description||"").length>170?"…":""}</p>
    ${contact ? `<a class="card-link" href="${contact}" target="_blank" rel="noopener noreferrer">Consultar por WhatsApp ↗</a>` : `<span class="card-link">Consulta próximamente disponible</span>`}</div>
  </article>`;
}
function render(items) {
  count.textContent = `${items.length} ${items.length === 1 ? "propiedad" : "propiedades"}`;
  grid.innerHTML = items.length ? items.map(card).join("") : '<div class="empty-state">No encontramos propiedades con esos filtros. Prueba otra búsqueda.</div>';
}
async function loadListings() {
  if (!isConfigured) {
    allListings = sampleListings;
    render(allListings);
    document.getElementById("configNotice").textContent = "Vista de demostración. Para mostrar anuncios reales, configura Supabase siguiendo README.md.";
    return;
  }
  try {
    const {data,error} = await window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY)
      .from("listings").select("id,title,property_type,price_usd,location,land_m2,built_m2,description,phone")
      .eq("status","approved").order("created_at",{ascending:false});
    if (error) throw error;
    allListings = data || [];
    render(allListings);
    document.getElementById("configNotice").textContent = "Los anuncios mostrados fueron aprobados por el administrador.";
  } catch (err) {
    allListings = [];
    render([]);
    document.getElementById("configNotice").textContent = "No se pudieron cargar los anuncios. Revisa la configuración de Supabase.";
    console.error(err);
  }
}
function filterListings() {
  const type = document.getElementById("typeFilter").value;
  const zone = document.getElementById("zoneFilter").value.trim().toLowerCase();
  const max = Number(document.getElementById("priceFilter").value) || Infinity;
  render(allListings.filter(x => (!type || x.property_type===type) && (!zone || String(x.location||"").toLowerCase().includes(zone) || String(x.title||"").toLowerCase().includes(zone)) && Number(x.price_usd)<=max));
}
document.getElementById("searchBtn").addEventListener("click",filterListings);
document.getElementById("zoneFilter").addEventListener("keydown",e=>{if(e.key==="Enter")filterListings();});

document.getElementById("listingForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.getElementById("formMessage");
  message.className = "form-message";
  if (!isConfigured) {
    message.classList.add("error");
    message.textContent = "El formulario todavía está en modo demostración. Primero conecta Supabase siguiendo README.md; aún no se ha enviado ni guardado tu anuncio.";
    return;
  }
  const values = Object.fromEntries(new FormData(form).entries());
  const payload = {
    contact_name: values.contact_name.trim(), phone: values.phone.trim(),
    title: values.title.trim(), property_type: values.property_type,
    price_usd: Number(values.price_usd), location: values.location.trim(),
    land_m2: values.land_m2 ? Number(values.land_m2) : null,
    built_m2: values.built_m2 ? Number(values.built_m2) : null,
    description: values.description.trim(), status: "pending"
  };
  const submit = form.querySelector('button[type="submit"]');
  submit.disabled = true; submit.textContent = "Enviando…";
  try {
    const client = window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
    const {error} = await client.from("listings").insert(payload);
    if (error) throw error;
    form.reset();
    message.classList.add("success");
    message.textContent = "¡Solicitud recibida! Quedó pendiente de revisión; solo se publicará si el administrador la aprueba.";
  } catch (err) {
    message.classList.add("error");
    message.textContent = "No se pudo enviar. Revisa la configuración de Supabase e inténtalo nuevamente.";
    console.error(err);
  } finally {
    submit.disabled = false; submit.innerHTML = 'Enviar para revisión <span>→</span>';
  }
});
loadListings();
