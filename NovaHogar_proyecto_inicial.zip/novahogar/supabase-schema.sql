-- NovaHogar: schema inicial para Supabase.
-- Ejecuta este script en Supabase > SQL Editor > New query.
-- Los visitantes solo pueden enviar anuncios en estado pending.
-- Solo el administrador debe aprobar desde el panel de Supabase.
create extension if not exists pgcrypto;

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  contact_name text not null check (char_length(contact_name) between 1 and 100),
  phone text not null check (char_length(phone) between 5 and 30),
  title text not null check (char_length(title) between 1 and 120),
  property_type text not null check (property_type in ('Casa','Departamento','Terreno','Comercial')),
  price_usd numeric not null check (price_usd > 0),
  location text not null check (char_length(location) between 1 and 180),
  land_m2 numeric check (land_m2 is null or land_m2 >= 0),
  built_m2 numeric check (built_m2 is null or built_m2 >= 0),
  description text not null check (char_length(description) between 1 and 2500),
  status text not null default 'pending' check (status in ('pending','approved','rejected'))
);

alter table public.listings enable row level security;

drop policy if exists "Public can read approved listings" on public.listings;
create policy "Public can read approved listings"
on public.listings for select
to anon, authenticated
using (status = 'approved');

drop policy if exists "Public can submit pending listings" on public.listings;
create policy "Public can submit pending listings"
on public.listings for insert
to anon, authenticated
with check (
  status = 'pending'
  and char_length(contact_name) between 1 and 100
  and char_length(phone) between 5 and 30
  and char_length(title) between 1 and 120
  and property_type in ('Casa','Departamento','Terreno','Comercial')
  and price_usd > 0
  and char_length(location) between 1 and 180
  and char_length(description) between 1 and 2500
);

-- No se crean políticas públicas de UPDATE o DELETE.
-- Para aprobar: en Table Editor, cambia status de pending a approved
-- usando la sesión del propietario del proyecto. Nunca compartas la service_role key.
