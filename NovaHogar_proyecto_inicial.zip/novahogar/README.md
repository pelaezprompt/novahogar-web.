# NovaHogar — primer prototipo

Sitio adaptable a móvil para mostrar propiedades, filtrar por tipo/zona/precio y recibir solicitudes de publicación. La marca NovaHogar es provisional y se puede cambiar.

## Qué funciona ahora
- Catálogo con una ficha de demostración de una casa en Plan 3000.
- Filtros básicos.
- Formulario visual para enviar inmuebles.
- Conexión opcional a Supabase para guardar solicitudes como `pending` y mostrar solo anuncios `approved`.

**Importante:** en el modo inicial, el formulario no guarda datos. No publiques el sitio como si ya estuviera conectado a una base de datos. Este paquete no tiene datos de acceso a tu cuenta.

## Paso 1 — subir a GitHub desde iPhone
1. Entra en https://github.com y crea un repositorio nuevo llamado `novahogar-web`.
2. Si aparece la opción de inicializar con README, puedes dejarla desmarcada.
3. En el repositorio, pulsa **Add file → Upload files** (si no aparece en móvil, abre el menú del navegador y activa “Solicitar sitio web de escritorio”).
4. Descomprime este ZIP en Archivos del iPhone si te resulta cómodo, y sube los archivos que están dentro de la carpeta `novahogar` (`index.html`, `styles.css`, `app.js`, `supabase-schema.sql`, `README.md`). No subas la carpeta ZIP como único archivo.
5. Confirma con **Commit changes**.

## Paso 2 — crear base de datos gratis en Supabase
1. Entra en https://supabase.com y crea un proyecto.
2. En **SQL Editor**, crea una consulta nueva, pega todo el contenido de `supabase-schema.sql` y pulsa Run.
3. En **Project Settings → API** (o sección equivalente), copia el Project URL y la clave pública `anon` / `publishable`.
4. En GitHub, abre `app.js` → lápiz Edit → reemplaza las dos cadenas vacías del inicio:
   - `SUPABASE_URL = ""`
   - `SUPABASE_ANON_KEY = ""`
   Pega únicamente el URL y la clave pública. Guarda con **Commit changes**.
5. Nunca pegues una `service_role`, `secret` key, contraseña ni código de acceso en el frontend.

## Paso 3 — publicar con Cloudflare Pages
1. Crea una cuenta en https://dash.cloudflare.com/ si no tienes.
2. Busca **Workers & Pages** → **Create** → Pages / Connect to Git.
3. Conecta GitHub y elige `novahogar-web`.
4. Para este sitio estático, deja el comando de build vacío y usa `.` como directorio de salida si la pantalla lo solicita.
5. Pulsa Deploy. Cada cambio que guardes en GitHub se podrá desplegar automáticamente.

La interfaz de Cloudflare puede cambiar; sigue la configuración que indique el panel.

## Paso 4 — revisar y aprobar anuncios
- Los visitantes pueden insertar filas nuevas solo con `status = pending`.
- La página pública solo lee filas con `status = approved`.
- Para revisar solicitudes, entra en Supabase → Table Editor → `listings`.
- Cambia `status` a `approved` o `rejected` desde la sesión propietaria del proyecto.
- La comisión de una venta se debe acordar por escrito antes de ofrecer el servicio.

## Limitaciones del prototipo
- No tiene acceso de administrador dentro del sitio; la aprobación se hace en el panel de Supabase.
- No permite subir fotos todavía; la ficha usa una ilustración.
- El formulario anónimo puede recibir spam. Antes de promocionarlo ampliamente, conviene añadir CAPTCHA / protección anti-spam y límites de uso.
- No pongas información sensible de clientes en el repositorio público.
- La configuración del proyecto, base de datos y hosting depende de tus propias cuentas y no está creada por este ZIP.
